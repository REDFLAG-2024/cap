document.addEventListener("DOMContentLoaded", function () {
    var navbar = document.getElementById("navbar");
    var scrolled = false;

    window.onscroll = function () {
        if (window.scrollY > 50 && !scrolled) {
            navbar.style.padding = "5px 20px";
            navbar.style.backgroundColor = "#222";
            scrolled = true;
        } else if (window.scrollY <= 50 && scrolled) {
            navbar.style.padding = "10px 20px";
            navbar.style.backgroundColor = "#333";
            scrolled = false;
        }
    };
});